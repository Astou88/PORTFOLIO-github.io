All the resources are used in this project are free for PERSONAL and COMMERCIAL use. 
Some of the resource requireq attribution (imaaes downloaded from https://www.freepik.com/, https://www.flaticon.com/)
 Enjoy ;)